(function($) {
  
	$("#notify").click(function(){
		var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		var email = $("#emailBox").val();
		if(email == "")
		{
			alert("Please enter your Email ID");
			$("#emailBox").focus();
		}
		else if(!regex.test(email))
		{
			alert("please enter a valid Email ID");
			$("#emailBox").focus();
		}
		else
		{
			
			alert("Thanks for Contact, Shortly we will reach to You");
				$.ajax({
					type: "POST",
					url: "send_email.php",
					data: { emailid : email },					
					success: function(result){
							if(result == 1)
							{
								alert("Thanks for your interest");
							}
							else{
								alert("fail :"+result);
							}
							//alert(result);
						}
				});
	       
			
		}
			
	});

})(jQuery);