<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Coming Soon - Campus4Laterals</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/coming-soon.min.css" rel="stylesheet">
    






    <!-- <script type="text/javascript">
      $(document).ready(function(){
          $("#notify").click(function(){
  alert("test");

});
          });
          </script> -->
  </head>

  <body>

    <div class="overlay"></div>

    <div class="masthead">
      <div class="masthead-bg"></div>
      <div class="container h-100">
        <div class="row h-100">
          <div class="col-lg-12" >
            <img src="img\logo3.png"  height="160px">
          </div>
          <div class="col-12 my-auto">
            <div class="masthead-content text-white py-5 py-md-0">
              <h1 class="mb-3 text-success">Campus4Laterals!</h1>
              <p class="mb-5">The lengthy and opaque lateral hiring process is about to change for premium candidates <br><br> We are <strong><FONT COLOR="yellow"> COMING SOON,</FONT></strong> watch this space! <br> Drop in your email id (Candiddate/Recruiter)</p>
              <div class="input-group input-group-newsletter">
                <input id="emailBox" type="email" class="form-control" placeholder="Enter email..." aria-label="Search for...">
                <span class="input-group-btn">
                  <button id="notify" class="btn btn-secondary" type="button" style="border-color:#5759cd;cursor: pointer;">Notify Me!</button>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
     <script type="text/javascript" src="js/c4l.js" ></script> 
    
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/vide/jquery.vide.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/coming-soon.min.js"></script>


  </body>

</html>
