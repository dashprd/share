<?php
	$to_mailId=$_POST['emailid'];
	$to = "info@campus4laterals.com";
	$subject = "Mail Notification";
	$txt = "Verify current Mail Id"+to_mailId;
	$headers = "From: prd@test.com";
	/*. "\r\n" .
	"CC: somebodyelse@example.com";*/

	$status= mail($to,$subject,$txt,$headers);
	echo $status;
?>